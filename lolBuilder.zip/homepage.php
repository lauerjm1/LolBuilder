<?php
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		if (isset($_POST["loginEmail"]) && isset($_POST["loginPass"]))
		{
			$loginPass= $_POST["loginPass"];
			$loginEmail = $_POST["loginEmail"];
			if ($loginPass === "" || $loginEmail === "")
			{
				echo "Incorrect Email or Password";
			}
			else
			{
			}
		//	include("homepage.html");
		}
	}
?>
