$(document).ready(function(){
	$(".button").on("click", function()
	{
		console.log($("button").attr(id));
	}
	)
}