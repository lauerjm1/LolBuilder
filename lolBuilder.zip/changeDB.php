 <?php
 
 
	function changeDB() {
   $dbhost = '127.0.0.1:3306';
   $dbuser = 'root';
   $dbpass = '';
   
   
   $connect = mysql_connect($dbhost, $dbuser, $dbpass);
   
   if(! $connect )
   {
      die('Could not connect: ' . mysql_error());
   }
   
   $sql = "INSERT INTO builds (userid, champimg, item1img, item2img,item3img, item4img, item5img, item6img)
VALUES ('".$_Session['user']"','".$_Session['champ']"', '".$_Session['item1']"', '".$_Session['item2']"','".$_Session['item3']"', '".$_Session['item4']"','".$_Session['item5']"','".$_Session['item6']"')";
  
  mysql_select_db('loleditor');
  
   if ($connect->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $connect->error;
}

   
   
   
   
   
   
    mysql_close($connect);
	}
   ?>